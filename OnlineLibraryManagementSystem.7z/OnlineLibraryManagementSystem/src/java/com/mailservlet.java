/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;   // important
import javax.mail.event.*;      // important
import java.net.*;
import java.util.*;

/**
 *
 */
public class mailservlet extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            out.println("<html><head></head><body>");
            Properties props = new Properties();
            props.put("mail.smtp.host", "localhost");   //  'localhost' for testing
            Session session1 = Session.getDefaultInstance(props, null);
            String s1 = request.getParameter("text1"); //sender (from)
            String s2 = request.getParameter("text2");
            String s3 = request.getParameter("text3");
            String s4 = request.getParameter("area1");
            Message message = new MimeMessage(session1);
            message.setFrom(new InternetAddress(s1));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(s2, false));
            message.setSubject(s3);
            message.setText(s4);
            Transport.send(message);
            out.println("mail has been sent</body></html>");

        } catch (MessagingException ex) {
            Logger.getLogger(mailservlet.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
